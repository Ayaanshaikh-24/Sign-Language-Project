# sign language > 2025-02-17 9:59pm
https://universe.roboflow.com/sign-language-83poo/sign-language-ld01o

Provided by a Roboflow user
License: CC BY 4.0

